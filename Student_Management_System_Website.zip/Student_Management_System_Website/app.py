import json
from pathlib import Path
import streamlit as st

DATA_FILE = Path(__file__).with_name("students.json")


class Student:
    """Node used by the singly linked list."""
    def __init__(self, roll_no, name, course, marks):
        self.roll_no = roll_no
        self.name = name
        self.course = course
        self.marks = marks
        self.next = None


class StudentLinkedList:
    """Simple singly linked list for student records."""
    def __init__(self):
        self.head = None

    def find(self, roll_no):
        current = self.head
        while current:
            if current.roll_no == roll_no:
                return current
            current = current.next
        return None

    def add(self, roll_no, name, course, marks):
        if self.find(roll_no):
            return False
        node = Student(roll_no, name, course, marks)
        if self.head is None:
            self.head = node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = node
        return True

    def delete(self, roll_no):
        current, previous = self.head, None
        while current and current.roll_no != roll_no:
            previous, current = current, current.next
        if current is None:
            return False
        if previous is None:
            self.head = current.next
        else:
            previous.next = current.next
        return True

    def all_students(self):
        result, current = [], self.head
        while current:
            result.append({
                "Roll No": current.roll_no,
                "Name": current.name,
                "Course": current.course,
                "Marks": current.marks,
            })
            current = current.next
        return result

    def update(self, roll_no, name, course, marks):
        student = self.find(roll_no)
        if student is None:
            return False
        student.name, student.course, student.marks = name, course, marks
        return True

    def sort_by_roll_no(self):
        # Bubble sort swaps node data while preserving the linked-list links.
        current = self.head
        while current:
            runner = current.next
            while runner:
                if current.roll_no > runner.roll_no:
                    current.roll_no, runner.roll_no = runner.roll_no, current.roll_no
                    current.name, runner.name = runner.name, current.name
                    current.course, runner.course = runner.course, current.course
                    current.marks, runner.marks = runner.marks, current.marks
                runner = runner.next
            current = current.next


def load_students():
    linked = StudentLinkedList()
    if DATA_FILE.exists():
        try:
            items = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            for item in items:
                linked.add(int(item["roll_no"]), str(item["name"]),
                           str(item["course"]), float(item["marks"]))
        except (json.JSONDecodeError, KeyError, TypeError, ValueError):
            st.warning("Could not read students.json. Starting with an empty list.")
    return linked


def save_students(linked):
    items = []
    for student in linked.all_students():
        items.append({
            "roll_no": student["Roll No"],
            "name": student["Name"],
            "course": student["Course"],
            "marks": student["Marks"],
        })
    DATA_FILE.write_text(json.dumps(items, indent=2), encoding="utf-8")


st.set_page_config(page_title="Student Management System", page_icon="🎓", layout="wide")
st.title("🎓 Student Management System")
st.caption("Python mini project demonstrating a singly linked list.")

if "students" not in st.session_state:
    st.session_state.students = load_students()

students = st.session_state.students

with st.sidebar:
    st.header("Menu")
    action = st.radio(
        "Choose an operation",
        ["Dashboard", "Add Student", "Search Student", "Update Student", "Delete Student", "Sort Students"]
    )
    st.divider()
    st.caption("Data structure: Singly Linked List")

if action == "Dashboard":
    records = students.all_students()
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Students", len(records))
    col2.metric("Average Marks", f"{sum(s['Marks'] for s in records) / len(records):.1f}" if records else "—")
    col3.metric("Courses", len(set(s["Course"] for s in records)) if records else 0)
    st.subheader("Student Records")
    if records:
        st.dataframe(records, use_container_width=True, hide_index=True)
    else:
        st.info("No student records yet. Choose **Add Student** from the menu.")

elif action == "Add Student":
    st.subheader("Add a Student")
    with st.form("add_student_form", clear_on_submit=True):
        roll_no = st.number_input("Roll number", min_value=1, step=1)
        name = st.text_input("Student name")
        course = st.text_input("Course")
        marks = st.number_input("Marks (0–100)", min_value=0.0, max_value=100.0, step=0.5)
        submitted = st.form_submit_button("Add Student", type="primary")
    if submitted:
        if not name.strip() or not course.strip():
            st.error("Please enter both name and course.")
        elif students.add(int(roll_no), name.strip(), course.strip(), float(marks)):
            save_students(students)
            st.success("Student added successfully!")
            st.rerun()
        else:
            st.error("That roll number already exists.")

elif action == "Search Student":
    st.subheader("Search Student")
    roll_no = st.number_input("Enter roll number", min_value=1, step=1, key="search_roll")
    if st.button("Search", type="primary"):
        student = students.find(int(roll_no))
        if student:
            st.success("Student found")
            st.table([{"Roll No": student.roll_no, "Name": student.name,
                       "Course": student.course, "Marks": student.marks}])
        else:
            st.warning("No student found with that roll number.")

elif action == "Update Student":
    st.subheader("Update Student")
    roll_no = st.number_input("Roll number to update", min_value=1, step=1, key="update_roll")
    student = students.find(int(roll_no))
    if student:
        with st.form("update_student_form"):
            name = st.text_input("New name", value=student.name)
            course = st.text_input("New course", value=student.course)
            marks = st.number_input("New marks", min_value=0.0, max_value=100.0,
                                    value=float(student.marks), step=0.5)
            submitted = st.form_submit_button("Save Changes", type="primary")
        if submitted:
            if not name.strip() or not course.strip():
                st.error("Name and course cannot be empty.")
            else:
                students.update(int(roll_no), name.strip(), course.strip(), float(marks))
                save_students(students)
                st.success("Student updated successfully!")
                st.rerun()
    else:
        st.info("Enter a roll number that exists in the records to show its details.")

elif action == "Delete Student":
    st.subheader("Delete Student")
    roll_no = st.number_input("Roll number to delete", min_value=1, step=1, key="delete_roll")
    if st.button("Delete Student", type="primary"):
        if students.delete(int(roll_no)):
            save_students(students)
            st.success("Student deleted successfully.")
            st.rerun()
        else:
            st.warning("Student not found.")

elif action == "Sort Students":
    st.subheader("Sort by Roll Number")
    if st.button("Sort Records", type="primary"):
        students.sort_by_roll_no()
        save_students(students)
        st.success("Student records sorted by roll number.")
    records = students.all_students()
    if records:
        st.dataframe(records, use_container_width=True, hide_index=True)
    else:
        st.info("No records to sort.")

st.divider()
st.caption("Mini project for Data Structures. For reliable permanent storage on a hosted website, connect a database; local files on free hosting may reset.")
