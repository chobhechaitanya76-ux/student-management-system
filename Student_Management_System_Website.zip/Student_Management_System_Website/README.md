# Student Management System — Online Website

Python Streamlit website for a Data Structures mini project. It implements a **singly linked list** for adding, displaying, searching, updating, deleting, and sorting student records.

## Run locally in VS Code

1. Extract the ZIP and open the folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Install the required package:

   ```powershell
   py -m pip install -r requirements.txt
   ```

4. Start the website:

   ```powershell
   py -m streamlit run app.py
   ```

5. Streamlit will show a local URL, usually `http://localhost:8501`.

## Publish online for a shareable link

### A. Upload the project to GitHub
1. Sign in or create an account at https://github.com/
2. Create a **new public repository**, for example `student-management-system`.
3. Upload `app.py`, `requirements.txt`, and `README.md` from this folder. Do not upload private student data.
4. Commit the files.

### B. Deploy with Streamlit Community Cloud
1. Visit https://share.streamlit.io/ and sign in with GitHub.
2. Select **Create app** (or **Deploy an app**).
3. Choose the repository you just created, the `main` branch, and `app.py` as the main file.
4. Click **Deploy**. After deployment finishes, Streamlit provides a public URL you can share.

## Important note about saving data
This starter project writes to `students.json`. On cloud hosting, local files may not be permanent and may reset when the app restarts or redeploys. Do not use real/private student information. For durable shared records, connect a database such as Supabase or another persistent database.
